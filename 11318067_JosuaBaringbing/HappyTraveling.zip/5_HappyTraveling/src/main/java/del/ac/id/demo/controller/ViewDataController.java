package del.ac.id.demo.controller;

import del.ac.id.demo.jpa.User;
import del.ac.id.demo.jpa.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;


@RestController
public class ViewDataController {
    @Autowired
    UserRepository userRepository;

    @GetMapping("/user/findAll")
    public List findAll(){
        List data = userRepository.findAll();

        ModelAndView mv = new ModelAndView("registration");
        mv.addObject("user", new User());
        return data;
    }
}
