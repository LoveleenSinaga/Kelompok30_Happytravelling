package del.ac.id.demo.controller;

import del.ac.id.demo.jpa.User;
import del.ac.id.demo.jpa.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;


@RestController
public class LoginController {

    @Autowired
    UserRepository userRepository;

    @GetMapping("/login")
    public ModelAndView login() {
        ModelAndView mv = new ModelAndView("login");
        return mv;
    }

    @GetMapping("/login/{username}/{password}")
    public ModelAndView login(@PathVariable String username, @PathVariable String password) {
        if (userRepository.findByUsername(username).getPwd() != null) {
            User user = userRepository.findByUsername(username);
            if (user.getPwd().equals(password)) {
                ModelAndView mv = new ModelAndView("Admin");
                return mv;
            }
        }
        ModelAndView mv = new ModelAndView("login");

        List data = userRepository.findAll();
        mv.addObject("data", data);

        return mv;
    }
}
